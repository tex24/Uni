//DA NON MODIFICARE
bool allDiffArrayElements(int*,int);
