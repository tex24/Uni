//DA NON MODIFICARE
int maxArray(int*,int);
