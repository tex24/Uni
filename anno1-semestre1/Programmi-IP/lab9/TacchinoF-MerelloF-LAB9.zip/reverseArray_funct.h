#ifndef reverseArray_funct
#define reverseArray_funct

void reverseArray(int *source, int *dest, int size);
void printArray(int s[], int size);

#endif