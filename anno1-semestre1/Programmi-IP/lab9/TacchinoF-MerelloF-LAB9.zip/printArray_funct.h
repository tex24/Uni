#ifndef printArray_funct
#define printArray_funct

void printArray(int* s, int size);
void printArrayWithIndex(int s[], int size);

#endif